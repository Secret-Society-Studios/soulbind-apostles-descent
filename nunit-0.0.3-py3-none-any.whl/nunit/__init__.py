"""init module 'nunit' package"""
